This is an example plugin.

In this example we show how to add right mouse menu entries
to the Object Tree which allow to script Views and Stored Procedures.

Since there is no standard for accessing Views and Stored Procedures
in a relational database a plugin like this must be a database specific
plugin. As an example we will script Views and Stored Procedures for
IBM UDB2 Version 8.2 running on Linux. 

