This plugin can help to detect violations of the Swing programming model.
Currently, only the violation of the Event dispatching thread. See http://java.sun.com/products/jfc/tsc/articles/threads/threads1.html

