Saved Queries Plugin

- TODO : document the Saved Queries Plugin here.